#include "ltequeue.h"

//int max_buff=51200;
int flow[100];

static class LTEQueueClass : public TclClass {
public:
	LTEQueueClass() : TclClass("Queue/LTEQueue") {}
	TclObject* create (int, const char*const*) {
		return (new LTEQueue);
	}
} class_ltequeue;

void LTEQueue::enque(Packet *p)
{
}
Packet* LTEQueue::deque()
{
}
