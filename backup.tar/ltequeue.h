#ifndef ns_ltequeue_h
#define ns_ltequeue_h

#include "drop-tail.h"
//#include "drr.h"
#include "red.h"

//extern int max_buf;
extern int flow[100];
extern int HVQ[100];

class LTEQueue : public Queue {
public:
	LTEQueue() {
		bind_bool("qos_", &qos_);
		bind_bool("flow_control_", &flow_control_);
		bind_bool("HVQ_UE",&HVQ_UE);
		for(int i=0;i<100;i++)
		{
		//defaut is no flow control
			flow[i]=0;
			HVQ[i]=-1;
		}
	}
	~LTEQueue() {
	}
	void enque(Packet* p);
	Packet *deque();
protected:
	int qos_;
	int flow_control_;
	int HVQ_UE;
};



#endif
